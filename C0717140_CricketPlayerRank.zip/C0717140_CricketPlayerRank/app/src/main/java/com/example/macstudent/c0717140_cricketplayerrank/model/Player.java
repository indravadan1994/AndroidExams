package com.example.macstudent.c0717140_cricketplayerrank.model;

/**
 * Created by macstudent on 2017-12-01.
 */

public class Player {

    //private variables
    int _id;
    String _name;
    String _gender;

    // Empty constructor
    public Player(){

    }
    // constructor
    public Player(int id, String name, String gender){
        this._id = id;
        this._name = name;
        this._gender = gender;
    }

    // constructor
    public Player(String name, String gender){
        this._name = name;
        this._gender = gender;
    }
    // getting ID
    public int getID(){
        return this._id;
    }

    // setting id
    public void setID(int id){
        this._id = id;
    }

    // getting name
    public String getName(){
        return this._name;
    }

    // setting name
    public void setName(String name){
        this._name = name;
    }

    // getting phone number
    public String getPhoneNumber(){
        return this._gender;
    }

    // setting phone number
    public void setPhoneNumber(String _gender){
        this._gender = _gender;
    }

}
