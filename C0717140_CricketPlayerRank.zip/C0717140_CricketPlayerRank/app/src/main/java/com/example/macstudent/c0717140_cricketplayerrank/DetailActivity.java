package com.example.macstudent.c0717140_cricketplayerrank;

import android.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import java.lang.String;
import java.util.List;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.macstudent.c0717140_cricketplayerrank.model.*;
import com.example.macstudent.c0717140_cricketplayerrank.model.Player;

public class DetailActivity extends AppCompatActivity {

    EditText txtName, txtGender, txtBdate, txtTestMatch, txtOneday, txtCatch, txtRun, txtWicket, txtStumping;
    Button btnSubmit;
    Spinner spCategory, spTeamCountry;



    DBPlayer dbPlayer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);


        ActionBar actionBar = getActionBar();
        if (actionBar != null) {
            actionBar.setTitle("Contact");
        }

        dbPlayer = new DBPlayer(this);

        txtName = (EditText)findViewById(R.id.txtName);
        txtGender= (EditText)findViewById(R.id.txtGender);
        btnSubmit = (Button)findViewById(R.id.btnSubmit);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dbPlayer.addContact(new Player(txtName.getText().toString(), txtGender.getText().toString()));

                Toast.makeText(DetailActivity.this,"Succesfull",
                        Toast.LENGTH_SHORT).show();
                Log.d("Reading: ", "Reading all contacts..");
                List<Player> contacts = dbPlayer.getAllContacts();

                for (Player cn : contacts) {
                    String log = "Id: " + cn.getID() + " ,Name: " + cn.getName() + " ,Phone: " + cn.getPhoneNumber();
                    // Writing Contacts to log
                    Log.d("Name: ", log);
                }
            }
        });



        // Reading all contacts



    }
}



